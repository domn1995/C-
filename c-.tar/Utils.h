#pragma once
#ifndef UTILSH
#define UTILSH

bool StrEq(const char* str, const char* comp);

#endif
