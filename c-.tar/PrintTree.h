#ifndef PRINTTREEH
#define PRINTTREEH
#include "TreeNode.h"

void Indent();
void PrintSyntaxTree(TreeNode* treeNode, int currSibling, bool annotated);

#endif